############################################################
# Piano Tiles
# 132 Design Expo
# Ah'Brittana Favor, Brianna Richardson
############################################################

# Import libraries and modules 
import pygame,os,random
from pygame.locals import *
from sounds import *
import RPi.GPIO as GPIO
from sounds import *
import time
import pyautogui

# Setup GPIO Buttons
GPIO.setmode(GPIO.BCM)
GPIO.setup(20, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(16, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(12, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(26, GPIO.IN, pull_up_down=GPIO.PUD_UP)



# Set screen size 
wix=900
wiy=1500

# Applies Buttons to quit by ESC key
from pygame.locals import (
	RLEACCEL,
	K_ESCAPE,
	KEYDOWN,
	QUIT,
)

# Set up mouse click positions
click_positions = [(113,1180), (338,1180), (563,1180), (788,1180)]

# Generate the Gameover Screen
def msg (screen,text,color=(55,55,55),size=36,pos=(-1,-1)):
	if pos[0] ==-1:pos=(screen.get_rect().centerx,pos[1])
	if pos[1] ==-1:pos=(pos[0],screen.get_rect().centery)
	font = pygame.font.Font(None, size)
	text = font.render(text, 1, color)
	textpos = text.get_rect()
	textpos.centerx = pos[0]
	textpos.centery= pos[1]
	screen.blit(text, textpos)
	
# Load correct sound files
def load_sound(name):
	if not pygame.mixer or not pygame.mixer.get_init():
		pass
	try:
		sound = pygame.mixer.Sound(os.path.join("sounds", name))
	except pygame.error:
		print ('Cannot load sound: %s' % name)
		raise SystemExit(str(KeyError()))
	return sound

# Class function for spawning falling tiles
class button():
	x=0
	y=-wiy//5
	h=wix//4-1
	l=wiy//5
	enclick=True
	# Spawns Tile in 1 of 4 columns
	def pos(self,n):
		self.x=n*wix//4
	# Animates falling motion of tiles
	def update(self,screen):
		if self.enclick :pygame.draw.rect(screen,(0,0,0),[self.x,self.y,self.h,self.l])
		else :pygame.draw.rect(screen,(180,180,180),[self.x,self.y,self.h,self.l])
	# Checks if click was executed on top of the tile
	def click(self,ps):
		if ps[0] in range(self.x,self.x+self.h):
			if ps[1] in range (self.y,self.y+self.l):
				self.enclick =False
				return 0
		return 1

# Initialize the to Start
pygame.init()
pygame.mixer.get_init()
mutrue=load_sound("key01.wav")
mufall= load_sound("key02.wav")
pygame.mixer.music.load("a.mp3")
clock=pygame.time.Clock()
screen=pygame.display.set_mode((wix,wiy))
mape=[0,0,0,0,1,1,1,2,2,2,3,3,3,1,2,3,1,0,2,3,1,0,1,2,3,0,1,2,3]
lost=0
time=0
delt=60
sb=[]
speey=10
score=0

# Start Game Loop
while lost == 0:
	for i in range (3):
		# Generates a tile
		sb.append(button())
		# At a random positions in one of the 4 columns
		sb[-1].pos(random.randrange(4))#(i)
		if lost!=0 : break
		for j in range(wiy//(5*speey)+1):
			time+=1/delt
			clock.tick(delt)
			screen.fill((224,224,255))
			# Places line where button clicks are located for each column
			pygame.draw.line(screen, (0, 0, 0), (0,1125), (wix, 1125), 2)
			# Checks if 
			if lost!=0 : break
			for k in range(len(sb)) :
				try:
					sb[k].y+=speey
					sb[k].update(screen)
					if sb[k].y >wiy-sb[k].l and sb[k].enclick == True : lost=1
				except : pass
			# For every refresh in the game scan for user input
			for event in pygame.event.get():
				if event.type == QUIT or \
					(event.type == KEYDOWN and event.key == K_ESCAPE):
					pygame.quit
				# Registers Mouse Click
				if event.type == MOUSEBUTTONDOWN:
						lost=sb[score].click(pygame.mouse.get_pos())
						if lost==0:mutrue.play()
						else :mufall.play()
						score+=1
				# Registers Button Presses
				if event.type == pygame.KEYDOWN:
					if GPIO.input(20) == GPIO.HIGH:
						print('key a has been pressed')
						pyautogui.click(click_positions[0])
						lost=sb[score].click(pygame.mouse.get_pos())
						if lost==0:mutrue.play()
						else :mufall.play()
						score+=1
					if GPIO.input(16) == GPIO.HIGH:
						print('key s has been pressed')
						pyautogui.click(click_positions[1])
						lost=sb[score].click(pygame.mouse.get_pos())
						if lost==0:mutrue.play()
						else :mufall.play()
						score+=1
					if GPIO.input(12) == GPIO.HIGH:
						print('key d has been pressed')
						pyautogui.click(click_positions[2])
						lost=sb[score].click(pygame.mouse.get_pos())
						if lost==0:mutrue.play()
						else :mufall.play()
						score+=1
					if GPIO.input(26) == GPIO.HIGH:
						print('key f has been pressed')
						pyautogui.click(click_positions[3])
						lost=sb[score].click(pygame.mouse.get_pos())
						if lost==0:mutrue.play()
						else :mufall.play()
						score+=1
			# Displays and refreshes the score module
			msg(screen,"SCORE "+str(score),color=(0,128,255),pos=(-1,30))
			pygame.display.update()
	# Increases speed by 1 for every 3 tiles clicked by user
	speey+=1
pygame.mixer.music.stop()
msg(screen,"GAME OVER",color=(110,128,225),size=100,pos=(-1,-1))
pygame.display.update()
pygame.time.wait(10000)